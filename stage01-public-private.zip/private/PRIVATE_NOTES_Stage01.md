# PRIVATE NOTES — Stage 01 Technical Details

> Internal document. Do not commit to the public repository.

---

## Purpose
Define and register the **data universe**: price series, benchmarks, and reference indices. Create a canonical **universe catalog** used by later stages.

---

## Local directories (example)
```
D:\2025\Fundo de Fatores\GitHub\factor-fund\
  data\input_bbg\           # provider exports (prices/benchmarks)
  data\input_macro\         # macro sources (if any)
  private\data_raw\         # optional raw dumps (mirrors of inputs)
  private\data_processed\catalog\  # processed catalog goes here
```

> Adjust to match your real layout.

---

## Universe catalog
Target path:
```
private\data_processed\catalog\universe.csv
```
Recommended columns:
```
ticker, provider_symbol, provider, asset_class, currency, start_date, end_date,
adjustments_flag, notes
```

- `ticker`: internal canonical ticker (string).  
- `provider_symbol`: vendor symbol as exported.  
- `provider`: e.g., Bloomberg, Economatica.  
- `asset_class`: Equity, Index, Benchmark, etc.  
- `currency`: BRL, USD, … (as exported).  
- `start_date`/`end_date`: first/last valid date in the export.  
- `adjustments_flag`: e.g., RAW/AJ (or other convention).  
- `notes`: free‑form comments.

---

## Minimal schema for prices (if staged now)
```
date, ticker, px_last, px_open, px_high, px_low, volume
```
- Dates as UTC → naive `YYYY‑MM‑DD`  
- One row per (`date`, `ticker`)

---

## Validation checklist
- Duplicates per (`date`, `ticker`) removed/flagged.  
- Missing dates measured vs. the **master calendar** (B3 + ANBIMA).  
- Currency and timezone recorded in the catalog.  
- Basic row counts and coverage summaries stored in a log.

---

## Notes
- Keep **all raw exports** outside Git; only the **catalog** and **tiny public samples** should be visible.  
- This stage feeds Stage 02 (corporate/economic integration) and later normalization steps.
