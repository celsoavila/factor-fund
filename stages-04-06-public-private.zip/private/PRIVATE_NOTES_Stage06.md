# PRIVATE NOTES — Stage 06 Technical Details

> Internal document. Do not commit to the public repository.

---

## Current split (fixed)
- Train/Validation: 2002–2017
- Test: 2018–2025‑08

## Files
```
private/data_processed/splits/index_train_valid_test.json
```
- Store explicit index ranges and seeds used for any internal CV.

## Suggested structure
{
  "train":   {"start": "2002-01-01", "end": "2017-12-31"},
  "valid":   "inside-train-or-kfold",
  "test":    {"start": "2018-01-01", "end": "2025-08-31"},
  "lag":     "T+1",
  "scalers": "fit on train only"
}

## Notes
- If you later move to walk‑forward, keep this file as the baseline split definition and add an array of rolling windows.
