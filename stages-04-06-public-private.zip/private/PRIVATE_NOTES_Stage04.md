# PRIVATE NOTES — Stage 04 Technical Details

> Internal document. Do not commit to the public repository.

---

## Overview
This stage produces two core artifacts:
- `returns_clean.parquet` (or equivalent cleaned panel)  
- `quality_mask.parquet` (boolean/score mask per `date`, `ticker`)

## Suggested flow (align with your implementation)
1) **Winsorization/clipping policy**  
   - Default: percentile clipping (e.g., 0.5%–99.5%) per column after grouping by ticker or cross‑section.  
   - Record exact thresholds used.

2) **Stale print flag**  
   - Heuristic examples: N consecutive identical values with volume>0, or price unchanged while peers move.  
   - Save `stale_flag` as separate column if useful.

3) **Mask construction**  
   - `quality_mask = (~outlier_flag) & (~stale_flag) & (notnull(metrics))`  
   - Optionally compute a confidence score in [0,1].

4) **Outputs**
```
private/data_processed/clean/returns_clean.parquet
private/data_processed/clean/quality_mask.parquet
```

## Checks
- Summary report: % clipped by asset and by date.  
- Before/after distribution plots for key columns.  
- Row counts after mask application.

## Dependencies
- pandas, numpy (and plotting libs for diagnostics).
