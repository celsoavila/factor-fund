# PRIVATE NOTES — Stage 05 Technical Details

> Internal document. Do not commit to the public repository.

---

## Feature catalog (customize with your exact specs)
- Momentum: ret_{21}, ret_{63}, ret_{126}, ret_{252}
- Volatility: vol_{21}, vol_{63}, vol_{252}
- Liquidity/turnover proxies: turnover_{21}, etc.
- Short DD: rolling min/max windows to compute local drawdowns
- Cross‑sectional z‑scores (optional): computed per date across tickers

## Alignment
- Associate features at date D with target/decision at D+1.  
- Ensure missing lags are dropped or masked.

## Outputs
```
private/data_processed/features/features_base.parquet
```

## Checks
- Leakage tests: shift features and confirm no forward info.  
- Coverage summary post‑mask and post‑lag.  
- Sanity plots (histograms/rolling stats).
