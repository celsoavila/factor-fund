# PRIVATE NOTES — Stage 03 Technical Details

> Internal document. Do not commit to the public repository.

---

## Overview
Stage 03 cleans and fills the two corporate/economic panels created in Stage 02:

- **Input 1:** `data/interim/02 - corp_data_1.csv`  → **Output:** `data/interim/03 - corp_data_1.csv` (+ optional `.xlsx`)  
- **Input 2:** `data/interim/02 - corp_data_2.csv`  → **Output:** `data/interim/03 - corp_data_2.csv`

Both scripts follow the same pattern:
- parse `date` with `utc=True`, sort by (`ticker`, `date`),
- coerce all indicator columns to numeric (except `date`/`ticker`),
- apply a **time-aware filling rule per ticker**, then
- normalize `date` to `YYYY-MM-DD` (naive) and re-sort by (`date`, `ticker`).

---

## Scripts

### 1) stage03_corp1_clean.py (corp_data_1)

**Paths**
```
INPUT : D:\2025\Fundo de Fatores\GitHub\factor-fund\data\interim\02 - corp_data_1.csv
OUTPUT: D:\2025\Fundo de Fatores\GitHub\factor-fund\data\interim\03 - corp_data_1.csv
XLSX  : D:\2025\Fundo de Fatores\GitHub\factor-fund\data\interim\03 - corp_data_1.xlsx (optional if <= 1,048,576 rows)
```

**Core parameters**
```
DATE_COL   = "date"
TICKER_COL = "ticker"
MAX_RANGE  = 360
MIN_VALID  = 2
SAVE_EXCEL_MAX_ROWS = 1_048_576
LOG_EVERY  = 50
```

**Filling rule (per column, per ticker)**
- For each NaN at position i:
  1. **Future-first**: scan forward (i+1 .. i+MAX_RANGE), collect up to MIN_VALID valid values and fill with their **mean** if at least MIN_VALID were found.
  2. **Past fallback**: if not enough future values, scan backward (i-1 .. i-MAX_RANGE) and fill with the mean of however many valid values exist (>=1).
  3. If no valid values found, keep NaN.

**Acceleration**
- If `numba` is installed, the core filling function runs with `@njit`. Otherwise, a no-op decorator is used (pure Python).
- Optional progress with `tqdm`.

---

### 2) stage03_corp2_clean.py (corp_data_2)

**Paths**
```
INPUT : D:\2025\Fundo de Fatores\GitHub\factor-fund\data\interim\02 - corp_data_2.csv
OUTPUT: D:\2025\Fundo de Fatores\GitHub\factor-fund\data\interim\03 - corp_data_2.csv
```

**Core parameters**
```
DATE_COL   = "date"
TICKER_COL = "ticker"
MAX_RANGE  = 30
MIN_VALID  = 10
LOG_EVERY  = 50
```

**Filling rule**
- Same future→past logic as corp_data_1, but with **shorter window** and **higher MIN_VALID**:
  - Forward scan up to MAX_RANGE=30 and require MIN_VALID=10 valid observations to fill.
  - If unmet, backward scan up to MAX_RANGE=30 using whatever valid values exist (>=1) to compute the mean.

---

## Shared behavior and checks

- Dates parsed with `utc=True`, then converted to naive and formatted `YYYY-MM-DD` for output.
- Sorting: initial (`ticker`, `date`) for filling logic; final (`date`, `ticker`) for downstream merges.
- Numeric coercion: `errors="coerce"` to avoid exceptions; invalid entries become `NaN`.
- Logs: `[OK]`/`[INFO]` messages for outputs; `[WARN]` for missing inputs.
- Duplicates: not explicitly dropped here; rely on upstream ingestion cleanliness or add a post‑fill duplicate check if needed.

---

## Dependencies

- `pandas`, `numpy`
- optional: `numba`, `tqdm`
