# PRIVATE NOTES — Stage 02 Technical Details

> Internal document. Do not commit to public repository.

---

## Overview

Stage 02 ingests and standardizes corporate and economic Excel files sourced from Bloomberg and Economatica terminals. These are internal exports located under:

```
D:\2025\Fundo de Fatores\GitHub\factor-fund\data\input_bbg\
```

Each file follows the naming convention:
```
02 - a - input_data_corp.xlsx
02 - b - input_data_corp.xlsx
...
02 - g - input_data_corp.xlsx
```

---

## Scripts

### 1. stage02_concat_corp1.py — Corporate Block 1 (Fundamentals + Economic panel)
- Excel block: Columns D:BK  
- Header row: 7 (skiprows=6)  
- Ticker source: Cell E5 (first 5 chars)  
- Iteration: sheets[4:]  
- Output CSV: data/interim/02 - corp_data_1.csv  
- Output Excel (if <= 1,048,576 rows): data/interim/02 - corp_data_1.xlsx

### 2. stage02_concat_corp2.py — Corporate Block 2 (Selected Ratios)
- Excel block: Columns BO:BT  
- Header row: 8 (skiprows=7)  
- Columns renamed: ['date','CUR_MKT_MKT_CAP','MKT_CAP_TO_ASSETS','PX_TO_FREE_CASH_FLOW','PX_TO_BOOK_RATIO','EARN_YLD']  
- Ticker source: Cell E5  
- Output CSV: data/interim/02 - corp_data_2.csv  
- Output Excel (if <= 1,048,576 rows): data/interim/02 - corp_data_2.xlsx

Shared behavior:
- Logs [WARN] for missing files or failed sheets.  
- Uses tqdm for progress display when installed.  
- Dates parsed with utc=True, then tz_localize(None), formatted as YYYY-MM-DD.  
- Numeric coercion errors replaced with NaN.

---

## Validation checks
- Column order and schema match expectations.  
- No duplicate (date, ticker) pairs.  
- No NaT after coercion.  
- Excel output only when under row limit.

---

## Dependencies
- pandas, openpyxl, optional tqdm.

---

## Directory Summary
```
data/input_bbg/          # Excel inputs (from Bloomberg/Economatica)
data/interim/            # Processed CSV/XLSX outputs
src/pipeline/            # Script location (stage02_concat_corp1.py / stage02_concat_corp2.py)
```

---

## Reminder
This file is for internal reference only.
Keep it under private/ and ensure .gitignore contains:
```
private/PRIVATE_NOTES.md
```
